﻿using System;
using System.Numerics;

class Program
{
    static void Main()
    {
        Program5();
    }

    static void Program5()
    {
        MyBigInteger a = new MyBigInteger("12345");
        MyBigInteger b = new MyBigInteger("54321");
        MyBigInteger mod = new MyBigInteger("1234");
        Console.WriteLine("a*b=" + a * b);
        Console.WriteLine("a+b=" + (a + b));
        Console.WriteLine("a*b mod 1234=" + (a * b) % mod);
        BigInteger a1 = BigInteger.Parse("12345");
        BigInteger a2 = BigInteger.Parse("54321");
        Console.WriteLine("a1*a2=" + a1 * a2);
        Console.WriteLine("a1+a2=" + (a1 + a2));
        Console.WriteLine("a1*a2 mod 1234=" + ((a1 * a2) % 1234));
    }
    static int Multiply(int a, int b, int m)
    {
        int result = 0;
        while (b > 0)
        {
            if ((b & 1) == 1)
            {
                result ^= a;
            }
            a <<= 1;
            if ((a & (1 << 16)) != 0)
            {
                a ^= m;
            }
            b >>= 1;
        }
        return result;
    }
    public static long ModInverse(long a, long m)
    {
        long m0 = m;
        long y = 0, x = 1;

        if (m == 1)
            return 0;
        try
        {
            while (a > 1)
            {
                long q = a / m;
                long t = m;

                m = a % m;
                a = t;
                t = y;

                y = x - q * y;
                x = t;
            }

            if (x < 0)
            {
                x += m0;
            }

            return x;
        }
        catch
        {
            return 0;
        }
    }
    static long ModPow(long a, long b, long m)
    {
        if (b == 0)
            return 1;

        long result = 1;
        a %= m;

        while (b > 0)
        {
            if ((b & 1) == 1)
                result = (result * a) % m;

            a = (a * a) % m;
            b >>= 1;
        }

        return result;
    }
    public static string DecimalToBinary(UInt64 decimalNumber)
    {
        string binaryString = "";
        do
        {
            binaryString = (decimalNumber % 2) + binaryString;
            decimalNumber /= 2;
        } while (decimalNumber > 0);

        return binaryString;
    }

}
public class MyBigInteger
{

    private string value;

    public MyBigInteger(string value)
    {
        this.value = value;
    }
    public static MyBigInteger operator +(MyBigInteger a, MyBigInteger b)
    {

        string result = Add(a.value, b.value);
        return new MyBigInteger(result);
    }

    public static MyBigInteger operator *(MyBigInteger a, MyBigInteger b)
    {

        string result = Multiply(a.value, b.value);
        return new MyBigInteger(result);
    }
    public override string ToString()
    {
        return value;
    }
    public static MyBigInteger operator %(MyBigInteger a, MyBigInteger modulus)
    {

        string result = Modulus(a.value, modulus.value);
        return new MyBigInteger(result);
    }
    private static string Add(string a, string b)
    {
        string result = "";
        int v = 0;
        for (int i = a.Length - 1; i >= 0; i--)
        {

            result = (((int.Parse(a[i].ToString())) + int.Parse(b[i].ToString()) + v) % 10) + result;
            if ((int.Parse(a[i].ToString()) + int.Parse(b[i].ToString()) + v) >= 10)
                if ((int.Parse(a[i].ToString()) + int.Parse(b[i].ToString()) + v) == 10)
                {
                    v = (int.Parse(a[i].ToString()) + int.Parse(b[i].ToString()) + v + 1) % 10;
                }
                else
                {
                    v = (int.Parse(a[i].ToString()) + int.Parse(b[i].ToString()) + v) % 10;
                }

        }
        return result;
    }
    private static string Multiply(string a, string b)
    {
        int len1 = a.Length;
        int len2 = b.Length;
        int[] product = new int[len1 + len2];

        for (int i = len1 - 1; i >= 0; i--)
        {
            for (int j = len2 - 1; j >= 0; j--)
            {
                int digit1 = a[i] - '0';
                int digit2 = b[j] - '0';
                int mul = digit1 * digit2;

                int p1 = i + j;
                int p2 = i + j + 1;

                int sum = mul + product[p2];

                product[p1] += sum / 10;
                product[p2] = sum % 10;
            }
        }

        string result = string.Join("", product).TrimStart('0');
        return string.IsNullOrEmpty(result) ? "0" : result;
    }
    private static string Modulus(string a, string modulus)
    {
        string result = a;
        string modulusString = modulus;
        string remainderString = "0";

        // Выполняем операцию взятия остатка (модуль)
        while (result.Length >= modulusString.Length)
        {
            int modLength = modulusString.Length;
            string currentSegment = result.Substring(0, modLength);

            int currentRemainder = int.Parse(remainderString + currentSegment) % int.Parse(modulusString);
            remainderString = currentRemainder.ToString();
            result = result.Substring(modLength);
        }


        return string.IsNullOrEmpty(remainderString + result) ? "0" : remainderString + result;
    }
} 
