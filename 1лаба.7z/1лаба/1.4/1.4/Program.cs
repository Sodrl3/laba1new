﻿using System;

class SieveOfEratosthenes
{
    static void Main()
    {
        int n = 100; // Задайте здесь верхнюю границу диапазона
        bool[] isPrime = new bool[n + 1];

        // Инициализируем все числа как простые
        for (int i = 2; i <= n; i++)
        {
            isPrime[i] = true;
        }

        // Начинаем отсеивать составные числа
        for (int p = 2; p * p <= n; p++)
        {
            if (isPrime[p] == true)
            {
                // Помечаем все кратные p как составные числа
                for (int i = p * p; i <= n; i += p)
                {
                    isPrime[i] = false;
                }
            }
        }

        // Выводим простые числа
        Console.WriteLine("Простые числа в диапазоне от 2 до " + n + ":");
        for (int i = 2; i <= n; i++)
        {
            if (isPrime[i])
            {
                Console.Write(i + " ");
            }
        }

        Console.WriteLine();
    }
}