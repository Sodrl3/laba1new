﻿using System;

class Program
{
    static void Main(string[] args)
    {
        if (args.Length != 3)
        {
            Console.WriteLine("Usage: Program.exe <command> <number1> <number2>");
            return;
        }

        string command = args[0].ToLower();
        ulong number1, number2;

        if (!ulong.TryParse(args[1], out number1) || !ulong.TryParse(args[2], out number2))
        {
            Console.WriteLine("Invalid input for numbers.");
            return;
        }

        ulong result = 0;

        switch (command)
        {
            case "xor":
                result = number1 ^ number2;
                break;
            case "and":
                result = number1 & number2;
                break;
            case "or":
                result = number1 | number2;
                break;
            case "set1":
                result = number2 | (1UL << (int)number1);
                break;
            case "set0":
                result = number2 & ~(1UL << (int)number1);
                break;
            case "shl":
                result = number2 << (int)number1;
                break;
            case "shr":
                result = number2 >> (int)number1;
                break;
            case "rol":
                result = (number2 << (int)number1) | (number2 >> (64 - (int)number1));
                break;
            case "ror":
                result = (number2 >> (int)number1) | (number2 << (64 - (int)number1));
                break;
            case "mix":
                result = MixBits(number1, number2);
                break;
            default:
                Console.WriteLine("Invalid command.");
                return;
        }

        Console.WriteLine($"Decimal: {result}");
        Console.WriteLine($"Hexadecimal: 0x{result:X}");
        Console.WriteLine($"Binary: {Convert.ToString((long)result, 2)}");
    }

    static ulong MixBits(ulong order, ulong value)
    {
        ulong result = 0;

        for (int i = 0; i < 64; i++)
        {
            ulong bit = (value >> (int)i) & 1;
            ulong newPosition = (order >> (int)i) & 7;
            result |= (bit << (int)newPosition);
        }

        return result;
    }
}
