﻿using System;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("введите путь к файлу");
        string filePath = Console.ReadLine();
        Console.WriteLine("Введите формат");
        string format = Console.ReadLine();

        byte[] data = File.ReadAllBytes(filePath);

        switch (format)
        {
            case "hex8":
                PrintHex8(data);
                break;
            case "dec8":
                PrintDec8(data);
                break;
            case "hex16":
                PrintHex16(data);
                break;
            case "dec16":
                PrintDec16(data);
                break;
            case "hex32":
                PrintHex32(data);
                break;
            default:
                Console.WriteLine("Invalid format specified.");
                break;
        }
    }

    static void PrintHex8(byte[] data)
    {
        foreach (byte b in data)
        {
            Console.Write(b.ToString("X2") + " ");
        }
        Console.WriteLine();
    }

    static void PrintDec8(byte[] data)
    {
        foreach (byte b in data)
        {
            Console.Write(b.ToString("D3") + " ");
        }
        Console.WriteLine();
    }

    static void PrintHex16(byte[] data)
    {
        for (int i = 0; i < data.Length; i += 2)
        {
            ushort word = BitConverter.ToUInt16(data, i);
            Console.Write(word.ToString("X4") + " ");
        }
        Console.WriteLine();
    }

    static void PrintDec16(byte[] data)
    {
        for (int i = 0; i < data.Length; i += 2)
        {
            ushort word = BitConverter.ToUInt16(data, i);
            Console.Write(word.ToString("D5") + " ");
        }
        Console.WriteLine();
    }

    static void PrintHex32(byte[] data)
    {
        for (int i = 0; i < data.Length; i += 4)
        {
            uint value = BitConverter.ToUInt32(data, i);
            Console.Write(value.ToString("X8") + " ");
        }
        Console.WriteLine();
    }
}
 