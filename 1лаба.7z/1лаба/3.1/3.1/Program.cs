﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Введите значение модуля m (M):");
        if (!ulong.TryParse(Console.ReadLine(), out ulong M) || M == 0)
        {
            Console.WriteLine("Неверное значение модуля m.");
            return;
        }

        while (true)
        {
            Console.WriteLine("Выберите операцию:");
            Console.WriteLine("1 - Сложение");
            Console.WriteLine("2 - Вычитание");
            Console.WriteLine("3 - Умножение");
            Console.WriteLine("4 - Возведение в степень");
            Console.WriteLine("5 - Поиск обратного элемента");
            Console.WriteLine("6 - Деление");
            Console.WriteLine("0 - Выход");

            if (!int.TryParse(Console.ReadLine(), out int choice))
            {
                Console.WriteLine("Некорректный ввод операции.");
                continue;
            }

            switch (choice)
            {
                case 0:
                    return;
                case 1:
                    Addition(M);
                    break;
                case 2:
                    Subtraction(M);
                    break;
                case 3:
                    Multiplication(M);
                    break;
                case 4:
                    Exponentiation(M);
                    break;
                case 5:
                    ModularInverse(M);
                    break;
                case 6:
                    Division(M);
                    break;
                default:
                    Console.WriteLine("Некорректная операция.");
                    break;
            }
        }
    }

    static void Addition(ulong M)
    {
        Console.WriteLine("Введите первое число:");
        if (!ulong.TryParse(Console.ReadLine(), out ulong a))
        {
            Console.WriteLine("Неверный формат числа.");
            return;
        }

        Console.WriteLine("Введите второе число:");
        if (!ulong.TryParse(Console.ReadLine(), out ulong b))
        {
            Console.WriteLine("Неверный формат числа.");
            return;
        }

        ulong result = (a + b) % M;
        Console.WriteLine($"Результат сложения: {result}");
    }

    static void Subtraction(ulong M)
    {
        Console.WriteLine("Введите уменьшаемое число:");
        if (!ulong.TryParse(Console.ReadLine(), out ulong a))
        {
            Console.WriteLine("Неверный формат числа.");
            return;
        }

        Console.WriteLine("Введите вычитаемое число:");
        if (!ulong.TryParse(Console.ReadLine(), out ulong b))
        {
            Console.WriteLine("Неверный формат числа.");
            return;
        }

        ulong result = (a - b + M) % M;
        Console.WriteLine($"Результат вычитания: {result}");
    }

    static void Multiplication(ulong M)
    {
        Console.WriteLine("Введите первое число:");
        if (!ulong.TryParse(Console.ReadLine(), out ulong a))
        {
            Console.WriteLine("Неверный формат числа.");
            return;
        }

        Console.WriteLine("Введите второе число:");
        if (!ulong.TryParse(Console.ReadLine(), out ulong b))
        {
            Console.WriteLine("Неверный формат числа.");
            return;
        }

        ulong result = (a * b) % M;
        Console.WriteLine($"Результат умножения: {result}");
    }

    static void Exponentiation(ulong M)
    {
        Console.WriteLine("Введите основание:");
        if (!ulong.TryParse(Console.ReadLine(), out ulong baseNum))
        {
            Console.WriteLine("Неверный формат числа.");
            return;
        }

        Console.WriteLine("Введите степень:");
        if (!ulong.TryParse(Console.ReadLine(), out ulong exponent))
        {
            Console.WriteLine("Неверный формат числа.");
            return;
        }

        ulong result = ModPow(baseNum, exponent, M);
        Console.WriteLine($"Результат возведения в степень: {result}");
    }

    static ulong ModPow(ulong baseNum, ulong exponent, ulong modulus)
    {
        ulong result = 1;
        baseNum %= modulus;

        while (exponent > 0)
        {
            if ((exponent & 1) == 1)
                result = (result * baseNum) % modulus;

            exponent >>= 1;
            baseNum = (baseNum * baseNum) % modulus;
        }

        return result;
    }

    static void ModularInverse(ulong M)
    {
        Console.WriteLine("Введите число, для которого хотите найти обратное:");
        if (!ulong.TryParse(Console.ReadLine(), out ulong num))
        {
            Console.WriteLine("Неверный формат числа.");
            return;
        }

        ulong inverse = ModInverse(num, M);

        if (inverse == 0)
            Console.WriteLine("Обратного элемента не существует.");
        else
            Console.WriteLine($"Обратный элемент: {inverse}");
    }

    static ulong ModInverse(ulong a, ulong m)
    {
        ulong m0 = m;
        ulong x0 = 0;
        ulong x1 = 1;

        if (m == 1)
            return 0;

        while (a > 1)
        {
            ulong q = a / m;
            ulong t = m;

            m = a % m;
            a = t;

            t = x0;
            x0 = x1 - q * x0;
            x1 = t;
        }

        if (x1 < 0)
            x1 += m0;

        return x1;
    }

    static void Division(ulong M)
    {
        Console.WriteLine("Введите делимое число:");
        if (!ulong.TryParse(Console.ReadLine(), out ulong a))
        {
            Console.WriteLine("Неверный формат числа.");
            return;
        }

        Console.WriteLine("Введите делитель:");
        if (!ulong.TryParse(Console.ReadLine(), out ulong b) || b == 0)
        {
            Console.WriteLine("Неверный формат числа или деление на ноль.");
            return;
        }

        ulong inverse = ModInverse(b, M);

        if (inverse == 0)
        {
            Console.WriteLine("Обратного элемента для делителя не существует.");
            return;
        }

        ulong result = (a * inverse) % M;
        Console.WriteLine($"Результат деления: {result}");
    }
}

