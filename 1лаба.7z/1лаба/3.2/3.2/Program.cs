﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Введите степень n (длина полинома):");
        if (!int.TryParse(Console.ReadLine(), out int n) || n <= 0)
        {
            Console.WriteLine("Неверное значение степени n.");
            return;
        }

        Console.WriteLine("Введите модуль M (полином для деления):");
        string M = Console.ReadLine();

        Console.WriteLine("Введите первый полином (в виде 101010):");
        string poly1 = Console.ReadLine();

        Console.WriteLine("Введите второй полином (в виде 101010):");
        string poly2 = Console.ReadLine();

        string result;

        Console.WriteLine("Выберите операцию:");
        Console.WriteLine("1 - Сложение");
        Console.WriteLine("2 - Вычитание");
        Console.WriteLine("3 - Умножение");
        Console.WriteLine("4 - Поиск обратного элемента");
        Console.WriteLine("5 - Деление");
        Console.WriteLine("0 - Выход");

        if (!int.TryParse(Console.ReadLine(), out int choice))
        {
            Console.WriteLine("Некорректный ввод операции.");
            return;
        }

        switch (choice)
        {
            case 0:
                return;
            case 1:
                result = AddPolynomials(poly1, poly2);
                break;
            case 2:
                result = SubtractPolynomials(poly1, poly2);
                break;
            case 3:
                result = MultiplyPolynomials(poly1, poly2, M);
                break;
            case 4:
                result = FindInverse(poly1, M);
                break;
            case 5:
                result = DividePolynomials(poly1, poly2, M);
                break;
            default:
                Console.WriteLine("Некорректная операция.");
                return;
        }
        uint res_dec = Convert.ToUInt32(result, 2);
        Console.WriteLine($"Результат: {result} == {res_dec}");
    }

    static string AddPolynomials(string poly1, string poly2)
    {
        int maxLength = Math.Max(poly1.Length, poly2.Length);
        poly1 = poly1.PadLeft(maxLength, '0');
        poly2 = poly2.PadLeft(maxLength, '0');

        char[] result = new char[maxLength];

        for (int i = 0; i < maxLength; i++)
        {
            result[i] = (poly1[i] == poly2[i]) ? '0' : '1';
        }

        return new string(result);
    }

    static string SubtractPolynomials(string poly1, string poly2)
    {
        return AddPolynomials(poly1, poly2); // В поле GF(2), вычитание равносильно сложению.
    }

    static string MultiplyPolynomials(string poly1, string poly2, string modulus)
    {
        string result = "0";

        for (int i = 0; i < poly2.Length; i++)
        {
            if (poly2[i] == '1')
            {
                string term = poly1;
                for (int j = 0; j < i; j++)
                {
                    term = "0" + term;
                }

                result = AddPolynomials(result, term);
            }
        }

        return result.Length >= modulus.Length ? DividePolynomials(result, modulus, modulus) : result;
    }

    static string FindInverse(string poly, string modulus)
    {
        for (int i = 0; i < 2 * modulus.Length; i++)
        {
            string candidate = MultiplyPolynomials(poly, new string('0', i) + "1", modulus);

            if (candidate == "1")
            {
                return poly;
            }
        }

        return "Обратного элемента не существует.";
    }

    static string DividePolynomials(string dividend, string divisor, string modulus)
    {
        int dividendLength = dividend.Length;
        int divisorLength = divisor.Length;

        if (divisorLength > dividendLength)
        {
            return "0";
        }

        string quotient = "";

        while (dividendLength >= divisorLength)
        {
            int shift = dividendLength - divisorLength;
            string term = MultiplyPolynomials(divisor, new string('0', shift) + "1", modulus);
            quotient += "1";
            dividend = AddPolynomials(dividend, term);
            dividendLength = dividend.Length;
        }

        return quotient;
    }
}
